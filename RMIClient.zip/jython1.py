import os

os.system("notepad.exe")